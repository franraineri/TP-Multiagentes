package com.company.AgentsPack;

import javax.swing.*;

public class GuiAgentFrame extends JFrame {
    private MyGuiAgent agent;
}
