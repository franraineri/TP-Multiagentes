package com.company.AgentsPack;
import jade.gui.GuiAgent;
import jade.gui.GuiEvent;

public class MyGuiAgent extends jade.gui.GuiAgent {

    @Override
    protected void onGuiEvent(GuiEvent guiEvent) {

    }
}
